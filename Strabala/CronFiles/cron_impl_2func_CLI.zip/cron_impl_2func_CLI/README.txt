

# This script is designed to 'configure' a fresh Couchbase 6.5.1 server install
# just make sure your SETUP parameters are correct (sorry this is only Mac / Linux )
#
# You can also delete all your Eventing Handlers and the three buckets 'metadata', 
# 'crondata', # and 'travel-sample' and run this again to setup a prestine environment.

# once the below is configured save the file and just run this file
#
# 	sh ./README.txt
#

# =======================
# BEG SETUP (your path, user, and pass will differ)

CB_INSTDIR=/opt/couchbase
CB_INSTDIR='/Applications/Couchbase Server.app/Contents/Resources/couchbase-core'
CB_INSTDIR=/space/linuxbrew/couch/install
PATH=${PATH}:${CB_INSTDIR}/bin
CB_USERNAME=Administrator
CB_PASSWORD=password

# END SETUP (your path, user, and pass will differ)
# =======================

# in the UI (or command line) create two buckets crondata AND metadata 100MB each, -also- load the travel-sample data set
	echo "Making buckets metadata and crondata and loading travel-sample bucket."

	couchbase-cli bucket-create -c localhost:8091 -u $CB_USERNAME -p $CB_PASSWORD  \
           --bucket=metadata  \
           --bucket-type=couchbase  \
           --bucket-ramsize=200  \
           --bucket-replica=0  \
           --enable-flush=1  \
           --wait

	couchbase-cli bucket-create -c localhost:8091 -u $CB_USERNAME -p $CB_PASSWORD  \
           --bucket=crondata  \
           --bucket-type=couchbase  \
           --bucket-ramsize=200  \
           --bucket-replica=0  \
           --enable-flush=1  \
           --wait

	cbdocloader -c localhost:8091 -u $CB_USERNAME -p $CB_PASSWORD -b "travel-sample" -m 100 \
	    -d "${CB_INSTDIR}/samples/travel-sample.zip"

# import eventing functions

	echo "Importing our two functions 'cron_impl_2func_651' and 'cron_impl_2func_651_help'."

	couchbase-cli eventing-function-setup -c localhost \
		-u $CB_USERNAME -p $CB_PASSWORD --import --file cron_impl_2func_651.json

	couchbase-cli eventing-function-setup -c localhost \
		-u $CB_USERNAME -p $CB_PASSWORD --import --file cron_impl_2func_651_help.json


# 	curl -u ${CB_USERNAME}:${CB_PASSWORD} http://localhost:8093/query/service \
# 		-d 'statement=CREATE PRIMARY INDEX on crondata'

# Create an INDEX so we can query the crondata set with N1QL

	echo "Create an INDEX so we can query the crondata bucket with N1QL."

	$CB_INST_BIN_PATH/curl -s -u ${CB_USERNAME}:${CB_PASSWORD} http://localhost:8093/query/service \
	  -d 'statement=CREATE PRIMARY INDEX p_idx_crondata ON crondata'


# Make sure you allow recursion

	echo "Allow cross bucket recursion (Couchbase trys to protect the causual user form recursive loops)."

	curl -X POST -u "$CB_USERNAME:$CB_PASSWORD" 'http://localhost:8091/_p/event/api/v1/config' \
		-d '{ "allow_interbucket_recursion":true }'

# in the UI (or command line) deploy both functions "cron_impl_2func_651_help" "cron_impl_2func_651"

	echo "Deploy our two functions 'cron_impl_2func_651' and 'cron_impl_2func_651_help'."

	curl -X POST -d '{"deployment_status":true,"processing_status":true}' \
		-s 'http://'${CB_USERNAME}:${CB_PASSWORD}'@localhost:8096/api/v1/functions/cron_impl_2func_651_help/settings'

	curl -X POST -d '{"deployment_status":true,"processing_status":true}' \
		-s 'http://'${CB_USERNAME}:${CB_PASSWORD}'@localhost:8096/api/v1/functions/cron_impl_2func_651/settings'

cat<<EOI

# The Couchbase server should be configured with three (3) buckets: travel-sample, metadata, and crondata
# You will also have two Eventing Functions imported and deployed "cron_impl_2func" and "cron_impl_2func_help"

# Now decide what you want to run. If you the example from the BLOG, e.g. one instance of action doCronActionA 
# or a larger test with 32 schedule

# CASE A) import JSON data for 1 active schedule to run the action doCronActionA (this is N1QL function) which runs 
# on the minute with verbose.user_func = 2 such that several lines log information file will be emmited for the
# user action on each run.  In addition the scheduling logic will be quite verbose due to verbose.scheduler = 3.
# the result is an updated cache document in bucket travel-sample with KEY cron_cache::airlines_by_country updated
# one a minute.  (If you choose this you will need to cut-n-paste it into the shell)

	cbimport json \\
		-c couchbase://127.0.0.1 -u $CB_USERNAME -p $CB_PASSWORD -b crondata \\
                -f lines -t 4 -g recurring_event::%id% \\
		-d file://./sched_data_run_1_doCronActionA.json

# CASE B) import JSON data for 32 active schedules to run the action doCronActionB (this is NOOP function) which runs 
# on the minute with verbose.user_func = 1 such that only one line of log file information be emmited on each run for
# the user action.  (If you choose this you will need to cut-n-paste it into the shell)

	cbimport json \\
		-c couchbase://127.0.0.1 -u $CB_USERNAME -p $CB_PASSWORD -b crondata \\
                -f lines -t 4 -g recurring_event::%id% \\
		-d file://./sched_data_run_32_doCronActionB.json

# You can inspect the log files in the Evienting UI by clicking "log" -or- you can look on a given eventing node
# and inspect the log files on your system (note if you have N eventing nodes a give node will only process 1/N
# of the total vBuckets).

# The Application logs for macOS is different form the Application install dir
# cd /Users/$USER/Library/Application Support/Couchbase/var/lib/couchbase/data/@eventing
# linux Application logs are by defualt under the CB_INSTDIR

# for the primary function ...

	cd $CB_INSTDIR/var/lib/couchbase/data/@eventing 
	tail -f cron_impl_2func_651.log

# for the helper function ...

	cd $CB_INSTDIR/var/lib/couchbase/data/@eventing 
	tail -f cron_impl_2func_651_help.log

EOI

