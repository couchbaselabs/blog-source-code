#!/bin/sh

BASE_DIR=/space/linuxbrew/citi_maps_jas
FAKEIT=/space/linuxbrew/fakeit
CB_HOME=/space/linuxbrew/couch/install/
CB_USERNAME=Administrator
CB_PASSWORD=password
PATH=${PATH}:${FAKEIT}/bin:${CB_HOME}/bin
#PATH=${PATH}$CB_HOME/bin

echo "LOAD UP RIGHTSCALE WITH CITI MPAS POC EMULATED DATA SET" 
echo "need 2 buckets maps_realtime and maps_realtime_out"
echo "sleep 10 .... ^C to kill"
sleep 10


nvm alias default 9
nvm use  9

# tar xvzf citi_maps_jas.tar.gz
cd ${BASE_DIR}
node --version
# v9.11.2
which fakeit
# /root/fakeit/bin/fakeit

fakeit couchbase --server localhost --bucket maps_realtime --verbose --username ${CB_USERNAME} --password ${CB_PASSWORD} --count 200000 ${BASE_DIR}/citi_position.yaml
fakeit couchbase --server localhost --bucket maps_realtime --verbose --username ${CB_USERNAME} --password ${CB_PASSWORD}  --count 25000 ${BASE_DIR}/citi_marketprice.yaml


# fakeit couchbase --server localhost --bucket maps_realtime --verbose --username ${CB_USERNAME} --password ${CB_PASSWORD}  --count 20000 ${BASE_DIR}/citi_position.yaml
# fakeit couchbase --server localhost --bucket maps_realtime --verbose --username ${CB_USERNAME} --password ${CB_PASSWORD}  --count 25000 ${BASE_DIR}/citi_marketprice.yaml
# fakeit console --count 5 ${BASE_DIR}/citi_position.yaml
# fakeit console --count 5 ${BASE_DIR}/citi_marketprice.yaml


node get_fxrate.js > ${BASE_DIR}/fxrate_doc.json
echo "loading data/fxrate_doc.json to KEY current_fxrate"
cbc create -u ${CB_USERNAME} -P ${CB_PASSWORD} -U http://localhost/maps_realtime current_fxrate < ${BASE_DIR}/fxrate_doc.json

echo
echo "# you must add an index ..."
echo "CREATE INDEX `my_idx_type` ON `maps_realtime`(`type`)"
