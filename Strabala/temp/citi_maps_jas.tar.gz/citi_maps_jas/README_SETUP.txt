
http://44.240.94.36:8091
Administrator/password

Jon - shell access is: root/Couchbase123!

umask

# ... must be 0002

curl https://raw.githubusercontent.com/creationix/nvm/v0.35.1/install.sh | bash
quit and restart shell
nvm install --lts
nvm install v9
nvm alias default 9
nvm use  9

npm install fakeit --global


/root/.nvm/versions/node/v9.11.2/bin/fakeit

### fix "catch {" blocks to "catch (e) {"
#
# vi +85 /root/.nvm/versions/node/v9.11.2/lib/node_modules/fakeit/node_modules/fs-extra/lib/mkdirs/make-dir.js
# vi +33 /root/.nvm/versions/node/v9.11.2/lib/node_modules/fakeit/node_modules/fs-extra/lib/empty/index.js
# vi +293 /root/.nvm/versions/node/v9.11.2/lib/node_modules/fakeit/node_modules/fs-extra/lib/remove/rimraf.js
# vi +7 /root/.nvm/versions/node/v9.11.2/lib/node_modules/fakeit/node_modules/fs-extra/lib/ensure/file.js
# vi /root/.nvm/versions/node/v9.11.2/lib/node_modules/fakeit/node_modules/fs-extra/lib/ensure/symlink-type.js





