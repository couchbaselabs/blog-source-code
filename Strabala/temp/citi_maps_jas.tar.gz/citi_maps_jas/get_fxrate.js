const fetch = require('node-fetch');

let url = "https://api.ratesapi.io/api/latest";

let settings = { method: "Get" };

fetch(url, settings)
    .then(res => res.json())
    .then((json) => {
        // do something with JSON
	var usd_to_euro = json.rates["USD"];
	//console.log(usd_to_euro);
        var rates = json.rates;
        rates['EUR'] = 1.0;
    
        for (var key in rates) {
	    rates[key] = rates[key] / usd_to_euro ;
        }
	var newdoc = {}
	newdoc.rates = rates;
	newdoc.dateTime = Date.now();
	newdoc.type = 'fxrate';
	console.log(JSON.stringify(newdoc));

	// console.log(json);
    });

